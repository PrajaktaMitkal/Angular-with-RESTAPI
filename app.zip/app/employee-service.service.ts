import { Injectable } from '@angular/core';
import {employeetable} from './employee';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable, of} from 'rxjs';

const httpOptions ={
  headers : new HttpHeaders ({'Content-Type':'application/json'})
};
@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {

  private employeeUrl =
  'http://localhost:8080/RESTMaven/api/employee';
  constructor(private http: HttpClient) { }


  addEmployee(employee :employeetable):Observable<employeetable>
  {
    return this.http.post<employeetable>(this.employeeUrl,employee,httpOptions);//.pipe(
    //  tap((employee:EmployeeRegistration)=>this.log('Employee Inserted id =${employee.empId}')),
  //    catchError(this.handleError<EmployeeRegistration>('addEmployee'))
    //);

  }
}