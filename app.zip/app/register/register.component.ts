import { Component, OnInit } from '@angular/core';
import {employeetable} from '../employee';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  addDetails(empid: number,city: string,designation: string,dob: string,emailid: string,Gender: string,graduation: string,name: string,password: string,postgraduation: string,skills: string,phone: string)
{
  
}
}
