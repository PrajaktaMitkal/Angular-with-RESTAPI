export class employeetable{
    empId: number;
    empName: string;
    empDesignation:string;
    empDob: string;
    empobilenum: string;
    empGraduation: string;
    empPostgraduation: string;
    empEmailId: string;
    empGender: string;
    empPassword: string;
    empSkills: string;
    empCity: string;
  
}